import { createPopper, popperGenerator } from "./index.js"; // eslint-disable-next-line import/no-unused-modules

export { createPopper, popperGenerator };